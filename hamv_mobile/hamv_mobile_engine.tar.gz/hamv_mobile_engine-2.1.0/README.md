# Micro Vertical App Engine

#### Build process:
1. npm i -g ionic rimraf
2. npm install
3. npm run build