export interface Group {
    name: string; //group name
    devices?: Array<string>;
    properties?: any;
}
